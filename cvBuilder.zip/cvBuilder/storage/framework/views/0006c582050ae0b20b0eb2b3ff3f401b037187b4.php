

<?php $__env->startSection('linkCSS'); ?>
<link rel="stylesheet" href="css/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

<h1>Create CV & PORTOFOLIO</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LEC\cvBuilder\resources\views/createcv.blade.php ENDPATH**/ ?>