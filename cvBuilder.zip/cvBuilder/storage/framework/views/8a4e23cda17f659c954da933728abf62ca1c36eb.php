

<?php $__env->startSection('linkCSS'); ?>
<link rel="stylesheet" href="css/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

    <h1 id="about-title">About Us</h1>
    <div class="about-content">
        <div class="dev-detail1">
            <h3>2301859335 | Adrian Rianto</h3>
        </div>
        <div class="dev-detail2">
            <h3>2301875830 | Stanley Feleri</h3>
        </div>
        <div class="dev-detail3">
            <h3>2301944481 | Naufaly Zuhdi</h3>
            <p>naufaly.indriandi@binus.ac.id</p>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LEC\cvBuilder\resources\views/about.blade.php ENDPATH**/ ?>