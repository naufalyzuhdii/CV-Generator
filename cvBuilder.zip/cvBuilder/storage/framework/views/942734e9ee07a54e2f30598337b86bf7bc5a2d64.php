

<?php $__env->startSection('container'); ?>
<div class="HeadQuote">
    <h1>BUILD AND LEVEL UP YOUR <br><span id="TopQuote"> CV AND PORTOFOLIO</span></h1>
    <div class="button">
        <a href="/signIn" class="signin">Sign In</a>
        <a href="/signUp" class="signup">Sign Up</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LEC\cvBuilder\resources\views/layouts/homepage.blade.php ENDPATH**/ ?>