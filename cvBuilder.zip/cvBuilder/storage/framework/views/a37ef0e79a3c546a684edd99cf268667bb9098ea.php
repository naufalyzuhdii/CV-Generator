<nav>
  

      <div class="navigation-wrapper">
        <div class="navigation-button">
          <i class="fa fa-bars"></i>
        </div>
        <div class="navigation-menu" style="z-index : 1;">
            <ul>
              <li><a href="/">HOME</a></li>
              <?php if(Auth::check()): ?>
                <li><a href="/createcv">CREATE CV</a></li>
              <?php else: ?>
                <li><a href="/signIn">SIGN IN</a></li>
              <?php endif; ?>
              <li><a href="/about">ABOUT US</a></li>
              <?php if(Auth::check()): ?>
                <li><a href="/logout">LOGOUT</a></li>
              <?php endif; ?>
          </ul>
        </div>
      </div>
</nav>
<?php /**PATH D:\Kuliah\Semester 5\Web Programming\LEC\cvBuilder\resources\views/partials/navbar.blade.php ENDPATH**/ ?>