<div class="button">
    <a href="/signIn" class="signin">Sign In</a>
    <a href="/signUp" class="signup">Sign Up</a>
</div><?php /**PATH D:\Kuliah\Semester 5\Web Programming\LEC\cvBuilder\resources\views/homepage/nonAuth.blade.php ENDPATH**/ ?>