<?php $__env->startSection('linkCSS'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php if(Auth::check()): ?>
    <style>
        body{
            min-height: 130vh;
        }
    </style>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="HeadQuote">
    <h1>BUILD AND LEVEL UP YOUR <br><span id="TopQuote"> CV AND PORTOFOLIO</span></h1>
    <?php if(Auth::check()): ?>
        <?php echo $__env->make('homepage.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('homepage.nonAuth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Stanley\Desktop\cvBuilder\resources\views/homepage/homepage.blade.php ENDPATH**/ ?>