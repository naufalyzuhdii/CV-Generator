    <div class="cards">
        <div class="card">
            <div class="card__image-holder">
                <img class="card__image" src="" alt=""/>
            </div>
            <div class="card-title">
                <button class="toggle-info-btn"><i class="fa fa-download"></i></button>
                <h2>
                    First CV
                    <small>Created on 19/12/2021</small>
                </h2>
            </div>
        </div>
        <div class="card">
            <div class="card__image-holder">
                <img class="card__image" src="" alt=""/>
            </div>
            <div class="card-title">
                <button class="toggle-info-btn"><i class="fa fa-download"></i></button>
                <h2>
                    Second CV
                    <small>Created on 19/12/2021</small>
                </h2>
            </div>
        </div>
        <div class="card">
            <div class="card__image-holder">
                <img class="card__image" src="" alt=""/>
            </div>
            <div class="card-title">
                <button class="toggle-info-btn"><i class="fa fa-download"></i></button>
                <h2>
                    Third CV
                    <small>Created on 19/12/2021</small>
                </h2>
            </div>
        </div>
        <div class="card">
            <div class="card__image-holder">
                <img class="card__image" src="" alt=""/>
            </div>
            <div class="card-title">
                <button class="toggle-info-btn"><i class="fa fa-download"></i></button>
                <h2>
                    Fourth CV
                    <small>Created on 19/12/2021</small>
                </h2>
            </div>
        </div>
        <div class="card">
            <div class="card__image-holder">
                <img class="card__image" src="" alt=""/>
            </div>
            <div class="card-title">
                <button class="toggle-info-btn"><i class="fa fa-download"></i></button>
                <h2>
                    Fifth CV
                    <small>Created on 19/12/2021</small>
                </h2>
            </div>
        </div>
    </div>
<?php /**PATH D:\Sunib\Sem 5\Web Prog\Project LEC\cvBuilder\resources\views/homepage/auth.blade.php ENDPATH**/ ?>