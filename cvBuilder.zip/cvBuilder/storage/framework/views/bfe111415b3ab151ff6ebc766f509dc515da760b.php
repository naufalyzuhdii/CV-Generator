<?php $__env->startSection('linkCSS'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

<div class="header">
    <h1>Create CV & PORTOFOLIO</h1>
</div>

<div class="summary">
    <h3>Summary</h3>
</div>

<div class="content">
    <div class="formskill">
        <form action="" enctype="multipart/form-data" method="POST">
    <?php echo csrf_field(); ?>

    <label for="skill">Skill</label>
    <input type="text" name="name" id="skill">
    <br>
    <input type="submit" value="Insert">
</form>

    </div>

    <div class="formexperience">
        <form action="" enctype="multipart/form-data" method="POST">
    <?php echo csrf_field(); ?>

    <label for="">Experience</label>
    <input type="text">
    <br>
    <input type="submit" value="Insert">
</form>
    </div>




</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Sem 5\Web Prog\Project LEC\cvBuilder\resources\views/test.blade.php ENDPATH**/ ?>