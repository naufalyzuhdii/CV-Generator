<div class="button">
    <a href="/signIn" class="signin">Sign In</a>
    <a href="/signUp" class="signup">Sign Up</a>
</div><?php /**PATH C:\Users\Stanley\Desktop\cvBuilder\resources\views/homepage/nonAuth.blade.php ENDPATH**/ ?>